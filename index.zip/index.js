const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const dummyReport = {
  url: "https://example.com",
  generated_at: new Date().toISOString(),

  ai_analysis: {
    operator_profile: {
      name: "サンプル不動産",
      company_type: "管理会社",
      transparency_level: "medium",
      official_info: "公式サイトに最低限の情報あり"
    },
    risk_factors: [
      {
        title: "初期費用が高め",
        description: "仲介手数料・鍵交換費用が相場より高い可能性",
        severity: "medium"
      }
    ],
    transparency_score: {
      score: 62,
      reason: "公式情報はあるが詳細が不足"
    },
    ai_warnings: [
      {
        title: "口コミ情報が少ない",
        detail: "ユーザー投稿が少なく、実態が不透明"
      }
    ]
  },

  human_sense: {
    smell: [],
    sound: [],
    air: [],
    environment: [],
    staff_attitude: [],
    intuition: [],
    other: []
  },

  personalized_insights: {
    user_profile: {
      sensitivity: {
        smell: "medium",
        sound: "medium",
        air: "medium",
        environment: "medium",
        staff_attitude: "medium",
        intuition: "medium"
      }
    },
    priority_points: [
      {
        title: "夜の雰囲気を確認",
        detail: "周辺環境の夜間の静けさを確認すると安心"
      }
    ]
  }
};

app.post("/report", (req, res) => {
  const { url } = req.body;
  const response = { ...dummyReport, url };
  res.json(response);
});

app.listen(3000, () => {
  console.log("sanpo dummy API running on http://localhost:3000");
});